Placeholder for documents folder
