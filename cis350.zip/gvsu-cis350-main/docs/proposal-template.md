Team name:

Team members:

# Introduction

(In 2-4 paragraphs, describe your project concept)
(Also define some loosely defined features of your project using bullet points)

# Anticipated Technologies

(What technologies are needed to build this project)

# Method/Approach

(What is your estimated "plan of attack" for developing this project)

# Estimated Timeline

(Figure out what your major milestones for this project will be, including how long you anticipate it *may* take to reach that point)

# Anticipated Problems

(Describe any problems you foresee that you will need to overcome)

Remember this is a living document is expected to be changed as you make progress on your project.
