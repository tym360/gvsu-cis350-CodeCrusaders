Placeholder for artifacts
